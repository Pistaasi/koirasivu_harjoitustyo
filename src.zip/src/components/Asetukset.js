import React from "react";
import AppBarMUI from "./AppBarMUI";

function Koira() {
    return (
    <div>
    <AppBarMUI/>
    <p> Asetuksia :D Testi testi kun pitäis jotain näihin reitityksiin keksiä
    </p>
    </div>
    );
    
    }
export default Koira; 