import React from "react";
import AppBarMUI from "./AppBarMUI";

function Koira() {
    return (
    <div>
    <AppBarMUI/>
    <p> Tyhjää täynnä (Vielä!), Tili ja asetukset sivu kuulostavat vähän tylsiltä itselle, varmaan reititän tänne jtn vähän kivempaa :D 
    </p>
    </div>
    );
    }
export default Koira; 