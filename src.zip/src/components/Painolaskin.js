import React from "react";

function Koira() {
    return (
    <p>Moi ope :D Tänne sivulle tulee koirien bmi laskuri. 
        <br/> Oma koira on laihdutuskuurilla niin ajattelin että tällainen voisi olla oikeasti hyödyllinen
        <br/> Täällä ei kuitenkaan nyt ole mitään, mutta meinaan lisätä lähiaikoina
    </p>);
    }
export default Koira; 