import KoiralistaMUI from "./KoiralistaMUI";
import React, { useState } from 'react';
import { useEffect } from "react";
import { Typography } from "@mui/material";

function HaeKoirat () {
    const [koiratdb, setKoiradb] = useState([]);
    const [virhe, setVirhe] = useState('Haetaan');
    const haeKaikkiKoirat = async () => {
    try {
    const response = await fetch('http://localhost:8080/koira/all');
    const json = await response.json();
    setKoiradb(json);
    setVirhe('');
    } catch (error) {
    setKoiradb([]);
    setVirhe('Koiria ei löytynyt :(');
    }
    }
    useEffect(() => {
    haeKaikkiKoirat();
    }, []);

    if (virhe.length > 0) {
        return ( <Typography>{ virhe }</Typography> );
        }
        if (koiratdb.length > 0) {
        return ( <KoiralistaMUI koiratdb={ koiratdb } /> );
        }
        return ( <Typography>Koiria ei vielä ole!</Typography> );
}

export default HaeKoirat;